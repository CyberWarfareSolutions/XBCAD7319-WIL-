﻿using Microsoft.AspNetCore.Mvc;

namespace StrayPaws.Controllers
{
    public class ContactUsController : Controller
    {
        public IActionResult List()
        {
            return View();
        }
    }
}
