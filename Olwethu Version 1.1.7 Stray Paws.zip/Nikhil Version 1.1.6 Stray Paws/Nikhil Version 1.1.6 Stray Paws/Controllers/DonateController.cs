﻿using Microsoft.AspNetCore.Mvc;

namespace StrayPaws.Controllers
{
    public class DonateController : Controller
    {
        public IActionResult List()
        {
            return View();
        }
    }
}
