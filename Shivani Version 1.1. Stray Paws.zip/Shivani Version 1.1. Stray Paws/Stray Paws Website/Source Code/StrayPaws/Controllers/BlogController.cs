﻿using Microsoft.AspNetCore.Mvc;

namespace StrayPaws.Controllers
{
    public class BlogController : Controller
    {
        public IActionResult List()
        {
            return View();
        }
    }
}
