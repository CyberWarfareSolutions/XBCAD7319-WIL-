﻿using Microsoft.AspNetCore.Mvc;

namespace StrayPaws.Controllers
{
    public class GalleryController : Controller
    {
        public IActionResult List()
        {
            return View();
        }
    }
}
