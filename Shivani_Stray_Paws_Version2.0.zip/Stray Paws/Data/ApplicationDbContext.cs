﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using Stray_Paws.Models;

namespace Stray_Paws.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<Stray_Paws.Models.DonateItems> DonateItems { get; set; }
        public DbSet<Stray_Paws.Models.Events> Events { get; set; }
        public DbSet<Stray_Paws.Models.Blog> Blog { get; set; }
        public DbSet<Stray_Paws.Models.BlogPosts> BlogPosts { get; set; }
        public DbSet<Stray_Paws.Models.Adopt> Adopt { get; set; }
       
    }
}
