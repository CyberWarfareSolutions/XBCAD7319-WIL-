﻿using System.ComponentModel.DataAnnotations;

namespace Stray_Paws.Models
{
    public class Adopt
    {

        [Key]
        public int AnimalID { get; set; }




        [Display(Name = "Animal Description")]
        [Required(ErrorMessage = "The Animal Description Is A Mandatory Field")]
        [MaxLength(300, ErrorMessage = "The Animal Description Cannot Have More Than 150 Characters")]
        [MinLength(5, ErrorMessage = "The Animal Description Must Have At Least 5 Characters")]
        public string AnimalDesc { get; set; }


        [Display(Name = "Animal Image")]


        public string AnimalImg { get; set; }




   


    }
}
