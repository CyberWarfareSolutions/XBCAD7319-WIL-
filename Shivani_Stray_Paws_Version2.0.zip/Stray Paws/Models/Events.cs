﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Stray_Paws.Models
{
    public class Events
    {
        /* This Class Contains The Necessary Variables For The Events Hosted By The NPO */

        [Key]
        public int EventID { get; set; }


        [Display(Name = "Event Name")]
        [Required(ErrorMessage = "The Event Name Is A Mandatory Field")]
        [MaxLength(200, ErrorMessage = "The Event Name Cannot Have More Than 200 Characters")]
        [MinLength(5, ErrorMessage = "The Item Name Must Have At Least 5 Characters")]
        public string EventName { get; set; }


        [Display(Name = "Event Description")]
        [Required(ErrorMessage = "The Event Description Is A Mandatory Field")]
        [MaxLength(300, ErrorMessage = "The Event Description Cannot Have More Than 300 Characters")]
        [MinLength(5, ErrorMessage = "The Event Description Must Have At Least 5 Characters")]
        public string EventDesc { get; set; }


        [Display(Name = "Event Date")]
        [Required(ErrorMessage = "The Event Is A Mandatory Field")]
        public DateTime EventDate { get; set; }


        [Display(Name = "Event Status")]
        [Required(ErrorMessage = "The Event Status Is A Mandatory Field")]
        [MaxLength(100, ErrorMessage = "The Event Status Cannot Have More Than 60 Characters")]
       
        public string EventStatus { get; set; }

        
        [Display(Name = "Item Image")]
        public string EventPoster { get; set; }
    }
}
