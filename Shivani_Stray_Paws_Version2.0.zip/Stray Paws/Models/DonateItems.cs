﻿using Microsoft.AspNetCore.Http;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Xml.Linq;

namespace Stray_Paws.Models
{
    public class DonateItems
    {
        /* This Class Contains The Necessary Variables For The Most Requested Items By The NPO */
        

        [Key]
        public int ItemID { get; set; }


        [Display(Name = "Item Name")]
        [Required(ErrorMessage = "The Item Name Is A Mandatory Field")]
        [MaxLength(100, ErrorMessage = "The Item Name Cannot Have More Than 60 Characters")]
        [MinLength(5, ErrorMessage = "The Item Name Must Have At Least 5 Characters")]
        public string ItemName { get; set; }


        [Display(Name = "Item Description")]
        [Required(ErrorMessage = "The Item Description Is A Mandatory Field")]
        [MaxLength(300, ErrorMessage = "The Item Description Cannot Have More Than 150 Characters")]
        [MinLength(5, ErrorMessage = "The Item Description Must Have At Least 5 Characters")]
        public string ItemDesc { get; set; }


        [Display(Name = "Item Image")]
      
      
        public string ItemURL { get; set; }

       


    }
        
}
