﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Azure.Storage.Blobs;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Stray_Paws.Data;
using Stray_Paws.Data.Migrations;
using Stray_Paws.Models;
using Blog = Stray_Paws.Models.Blog;

namespace Stray_Paws.Controllers
{
    public class BlogsController : Controller
    {
        private readonly BlobServiceClient _blobServiceClient;
        private readonly string _containerName = "donateditems";
        private readonly ApplicationDbContext _context;
        private string imageUrl;

        public BlogsController(ApplicationDbContext context, BlobServiceClient blobServiceClient)
        {
            _context = context;
            _blobServiceClient = blobServiceClient;
        }

        // GET: Blogs
        public async Task<IActionResult> Index()
        {
            return View(await _context.Blog.ToListAsync());
        }

        // GET: Blogs/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var blog = await _context.Blog
                .FirstOrDefaultAsync(m => m.BlogID == id);
            if (blog == null)
            {
                return NotFound();
            }

            return View(blog);
        }

        // GET: Blogs/Create
        public IActionResult Create()
        {
            return View();
        }

       
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("BlogID,BlogTitle,BlogDesc,BlogDate,BlogPoster")] Blog blog, IFormFile file)
        {
            if (ModelState.IsValid)
            {

                if (file != null && file.Length > 0)
                {
                    // Upload the file to Azure Blob Storage
                    string imageUrl = await UploadFileToAzureStorage(file, "donateditems"); // Use your container name

                    // Set the URL in the DonateItems model
                    blog.BlogPoster = imageUrl;
                }

                _context.Add(blog);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(blog);
        }

        private async Task<string> UploadFileToAzureStorage(IFormFile file, string containerName)
        {
            string connectionString = "DefaultEndpointsProtocol=https;AccountName=straypawsstorage;AccountKey=Z2MDQjGy1ojX5dgM/ij9faXwToEJqWW/G5/jje1CczZrvZfnVprArtvzFZweW0YUonN/QrGhirdX+AStdeO++w==;EndpointSuffix=core.windows.net";


            BlobServiceClient blobServiceClient = new BlobServiceClient(connectionString);
            BlobContainerClient containerClient = blobServiceClient.GetBlobContainerClient(containerName);


            string fileName = Guid.NewGuid().ToString() + Path.GetExtension(file.FileName);
            BlobClient blobClient = containerClient.GetBlobClient(fileName);

            using (var stream = file.OpenReadStream())
            {
                await blobClient.UploadAsync(stream, true);
            }

            return GetBlobUrl(containerName, fileName);
        }

        private string GetBlobUrl(string containerName, string blobName)
        {
            // Retrieve your Azure Blob Storage base URL from the connection string
            string connectionString = "DefaultEndpointsProtocol=https;AccountName=straypawsstorage;AccountKey=Z2MDQjGy1ojX5dgM/ij9faXwToEJqWW/G5/jje1CczZrvZfnVprArtvzFZweW0YUonN/QrGhirdX+AStdeO++w==;EndpointSuffix=core.windows.net";
            BlobServiceClient blobServiceClient = new BlobServiceClient(connectionString);

            // Construct the full URL
            string blobUrl = blobServiceClient.GetBlobContainerClient(containerName)
                                              .GetBlobClient(blobName)
                                              .Uri.ToString();

            return blobUrl;
        }

        // GET: Blogs/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var blog = await _context.Blog.FindAsync(id);
            if (blog == null)
            {
                return NotFound();
            }
            return View(blog);
        }

        // POST: Blogs/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("BlogID,BlogTitle,BlogDesc,BlogDate,BlogPoster")] Blog blog)
        {
            if (id != blog.BlogID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(blog);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BlogExists(blog.BlogID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(blog);
        }

        // GET: Blogs/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var blog = await _context.Blog
                .FirstOrDefaultAsync(m => m.BlogID == id);
            if (blog == null)
            {
                return NotFound();
            }

            return View(blog);
        }

        // POST: Blogs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var blog = await _context.Blog.FindAsync(id);
            _context.Blog.Remove(blog);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool BlogExists(int id)
        {
            return _context.Blog.Any(e => e.BlogID == id);
        }
    }
}
