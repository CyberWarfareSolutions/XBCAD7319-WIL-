﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using MimeKit;
using MailKit.Net.Smtp;
using System.Threading.Tasks;
using Stray_Paws.Models;
using System;
using System.Net.Mail;
using System.Net;


namespace Stray_Paws.Controllers
{
    public class Contact : Controller
    {
        private readonly IConfiguration _configuration;

        public Contact(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public IActionResult Index()
        {
            return View();
        }

       


    }
}
