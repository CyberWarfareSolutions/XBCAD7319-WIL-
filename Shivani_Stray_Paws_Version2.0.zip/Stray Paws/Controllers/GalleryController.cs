﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace Stray_Paws.Controllers
{
    public class GalleryController : Controller
    {
        private readonly BlobServiceClient _blobServiceClient;
        private readonly string _containerName = "donateditems";

        public GalleryController(BlobServiceClient blobServiceClient)
        {
            _blobServiceClient = blobServiceClient;
        }

        public async Task<IActionResult> Index()
        {
            BlobContainerClient containerClient = _blobServiceClient.GetBlobContainerClient(_containerName);

            List<BlobItem> blobs = new List<BlobItem>();
            await foreach (BlobItem blobItem in containerClient.GetBlobsAsync())
            {
                blobs.Add(blobItem);
            }

            return View(blobs);
        }

        public async Task<IActionResult> UploadFile(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                return BadRequest("File is not selected or empty.");
            }

            BlobContainerClient containerClient = _blobServiceClient.GetBlobContainerClient(_containerName);
            BlobClient blobClient = containerClient.GetBlobClient(file.FileName);

            using (var stream = file.OpenReadStream())
            {
                await blobClient.UploadAsync(stream, true);
            }

            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> DownloadFile(string fileName)
        {
            BlobContainerClient containerClient = _blobServiceClient.GetBlobContainerClient(_containerName);
            BlobClient blobClient = containerClient.GetBlobClient(fileName);

            BlobDownloadInfo blobDownloadInfo = await blobClient.DownloadAsync();

            MemoryStream ms = new MemoryStream();
            await blobDownloadInfo.Content.CopyToAsync(ms);
            ms.Seek(0, SeekOrigin.Begin);

            return File(ms, blobDownloadInfo.ContentType, fileName);
        }


        [HttpPost]
        public async Task<IActionResult> DeleteFile(string fileName)
        {
            if (string.IsNullOrWhiteSpace(fileName))
            {
                return BadRequest("Invalid file name.");
            }

            BlobContainerClient containerClient = _blobServiceClient.GetBlobContainerClient(_containerName);
            BlobClient blobClient = containerClient.GetBlobClient(fileName);

            await blobClient.DeleteIfExistsAsync();

            return RedirectToAction("Index");
        }
        [HttpGet]
        public async Task<IActionResult> GetImage(string fileName)
        {
            if (string.IsNullOrWhiteSpace(fileName))
            {
                return BadRequest("Invalid file name.");
            }

            BlobContainerClient containerClient = _blobServiceClient.GetBlobContainerClient(_containerName);
            BlobClient blobClient = containerClient.GetBlobClient(fileName);

            BlobDownloadInfo blobDownloadInfo = await blobClient.DownloadAsync();
            Stream stream = blobDownloadInfo.Content;

            // Set the appropriate content type for the image (e.g., "image/jpeg", "image/png", etc.).
            string contentType = blobDownloadInfo.ContentType;

            return File(stream, contentType);
        }
    }
}
