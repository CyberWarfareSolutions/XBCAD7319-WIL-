﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Stray_Paws.Data.Migrations
{
    public partial class RegLoginFeature : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
