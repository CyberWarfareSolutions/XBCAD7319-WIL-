﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Stray_Paws.Data.Migrations
{
    public partial class AddedAdopt : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Adopt",
                columns: table => new
                {
                    AnimalID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AnimalDesc = table.Column<string>(type: "nvarchar(300)", maxLength: 300, nullable: false),
                    AnimalImg = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Adopt", x => x.AnimalID);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Adopt");
        }
    }
}
