﻿using System.ComponentModel.DataAnnotations;
using System;

namespace Stray_Paws.Models
{
    public class Blog
    {
        /* This Class Contains The Necessary Variables For The Blog Feature */

        [Key]
        public int BlogID { get; set; }


        [Display(Name = "Blog Title")]
        [Required(ErrorMessage = "The Blog Title Is A Mandatory Field")]
        [MaxLength(200, ErrorMessage = "The Blog Title Cannot Have More Than 200 Characters")]
        [MinLength(5, ErrorMessage = "The Blog Title Must Have At Least 5 Characters")]
        public string BlogTitle { get; set; }


        [Display(Name = "Blog Description")]
        [Required(ErrorMessage = "The Blog Description Is A Mandatory Field")]
        [MaxLength(300, ErrorMessage = "The Blog Description Cannot Have More Than 300 Characters")]
        [MinLength(5, ErrorMessage = "The Blog Description Must Have At Least 5 Characters")]
        public string BlogDesc { get; set; }


        [Display(Name = "Blog Date")]
        [Required(ErrorMessage = "The Blog Date Is A Mandatory Field")]
        public DateTime BlogDate { get; set; }


 
        [Display(Name = "Blog Image")]
        public string BlogPoster { get; set; }
    }
}
