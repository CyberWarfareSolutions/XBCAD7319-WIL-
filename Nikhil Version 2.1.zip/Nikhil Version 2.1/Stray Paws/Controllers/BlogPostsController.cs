﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Azure.Storage.Blobs;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Stray_Paws.Data;
using Stray_Paws.Data.Migrations;
using Stray_Paws.Models;

namespace Stray_Paws.Controllers
{
    public class BlogPostsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly BlobServiceClient _blobServiceClient;
        private readonly string _containerName = "donateditems";
        private string imageUrl;

        public BlogPostsController(ApplicationDbContext context, BlobServiceClient blobServiceClient)
        {
            _context = context;
            _blobServiceClient = blobServiceClient;
        }

        // GET: BlogPosts
        public async Task<IActionResult> Index()
        {
            return View(await _context.BlogPosts.ToListAsync());
        }

        // GET: BlogPosts/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var blogPosts = await _context.BlogPosts
                .FirstOrDefaultAsync(m => m.BlogID == id);
            if (blogPosts == null)
            {
                return NotFound();
            }

            return View(blogPosts);
        }

        // GET: BlogPosts/Create
        public IActionResult Create()
        {
            return View();
        }

       
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("BlogID,BlogTitle,BlogDesc,BlogDate,BlogPoster")] BlogPosts blogPosts, IFormFile file)
        {
            if (ModelState.IsValid)
            {

                if (file != null && file.Length > 0)
                {
                    // Upload the file to Azure Blob Storage
                    string imageUrl = await UploadFileToAzureStorage(file, "donateditems"); // Use your container name

                    // Set the URL in the DonateItems model
                    blogPosts.BlogPoster = imageUrl;
                }

                _context.Add(blogPosts);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(blogPosts);
        }

        private async Task<string> UploadFileToAzureStorage(IFormFile file, string containerName)
        {
            string connectionString = "DefaultEndpointsProtocol=https;AccountName=straypawsstorage;AccountKey=Z2MDQjGy1ojX5dgM/ij9faXwToEJqWW/G5/jje1CczZrvZfnVprArtvzFZweW0YUonN/QrGhirdX+AStdeO++w==;EndpointSuffix=core.windows.net";


            BlobServiceClient blobServiceClient = new BlobServiceClient(connectionString);
            BlobContainerClient containerClient = blobServiceClient.GetBlobContainerClient(containerName);


            string fileName = Guid.NewGuid().ToString() + Path.GetExtension(file.FileName);
            BlobClient blobClient = containerClient.GetBlobClient(fileName);

            using (var stream = file.OpenReadStream())
            {
                await blobClient.UploadAsync(stream, true);
            }

            return GetBlobUrl(containerName, fileName);
        }

        private string GetBlobUrl(string containerName, string blobName)
        {
            // Retrieve your Azure Blob Storage base URL from the connection string
            string connectionString = "DefaultEndpointsProtocol=https;AccountName=straypawsstorage;AccountKey=Z2MDQjGy1ojX5dgM/ij9faXwToEJqWW/G5/jje1CczZrvZfnVprArtvzFZweW0YUonN/QrGhirdX+AStdeO++w==;EndpointSuffix=core.windows.net";
            BlobServiceClient blobServiceClient = new BlobServiceClient(connectionString);

            // Construct the full URL
            string blobUrl = blobServiceClient.GetBlobContainerClient(containerName)
                                              .GetBlobClient(blobName)
                                              .Uri.ToString();

            return blobUrl;
        }

        // GET: BlogPosts/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var blogPosts = await _context.BlogPosts.FindAsync(id);
            if (blogPosts == null)
            {
                return NotFound();
            }
            return View(blogPosts);
        }

        // POST: BlogPosts/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("BlogID,BlogTitle,BlogDesc,BlogDate,BlogPoster")] BlogPosts blogPosts)
        {
            if (id != blogPosts.BlogID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(blogPosts);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BlogPostsExists(blogPosts.BlogID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(blogPosts);
        }

        // GET: BlogPosts/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var blogPosts = await _context.BlogPosts
                .FirstOrDefaultAsync(m => m.BlogID == id);
            if (blogPosts == null)
            {
                return NotFound();
            }

            return View(blogPosts);
        }

        // POST: BlogPosts/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var blogPosts = await _context.BlogPosts.FindAsync(id);
            _context.BlogPosts.Remove(blogPosts);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool BlogPostsExists(int id)
        {
            return _context.BlogPosts.Any(e => e.BlogID == id);
        }
    }
}
