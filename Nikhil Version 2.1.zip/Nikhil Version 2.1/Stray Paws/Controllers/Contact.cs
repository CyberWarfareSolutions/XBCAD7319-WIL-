﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Net;
using System.Net.Mail;

namespace Stray_Paws.Controllers
{
    public class Contact : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }
    }
}