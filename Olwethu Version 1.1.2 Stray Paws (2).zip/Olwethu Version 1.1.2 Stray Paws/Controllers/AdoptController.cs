﻿using Microsoft.AspNetCore.Mvc;

namespace StrayPaws.Controllers
{
    public class AdoptController : Controller
    {
        public IActionResult List()
        {
            return View();
        }
    }
}
