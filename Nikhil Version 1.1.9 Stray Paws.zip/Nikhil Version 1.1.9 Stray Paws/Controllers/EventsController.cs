﻿using Microsoft.AspNetCore.Mvc;

namespace StrayPaws.Controllers
{
    public class EventsController : Controller
    {
        public IActionResult List()
        {
            return View();
        }
    }
}
